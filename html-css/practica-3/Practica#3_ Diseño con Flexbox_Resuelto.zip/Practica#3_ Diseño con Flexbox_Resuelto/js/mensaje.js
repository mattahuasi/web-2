
  $("#enviar").click(function(){
      Swal.fire({
      title: "Esta seguro(a)?",
      text: "Usted puede cancelar la operacion!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Si, borralo!"
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire({
          title: "Deleted!",
          text: "Su archivo ha sido eliminado.",
          icon: "success"
        });
      }
    });
  });



